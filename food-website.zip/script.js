function orderNow() {
  alert("ধন্যবাদ! আপনার অর্ডার গ্রহণ করা হয়েছে। 🍽️");
}
